import 'package:flutter_bloc/flutter_bloc.dart';

class Employee extends Cubit<int> {
  Employee() : super(0);

  void increment() => emit(state + 1);
  void decrement() => emit(state - 1);
}

class EmployeeIT extends Cubit<int> {
  EmployeeIT() : super(0);

  void increment() => emit(state + 1);
  void decrement() => emit(state - 1);
}

class EmployeeHR extends Cubit<int> {
  EmployeeHR() : super(0);

  void increment() => emit(state + 1);
  void decrement() => emit(state - 1);
}