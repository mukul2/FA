import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'Streams.dart';
import 'employees_bloc.dart';

void main() {
  runApp(const MyApp());
}

enum EmloyeType{HR,IT}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: EmployeesScreen(),
    );
  }
}
class EmployeesScreen extends StatefulWidget {
   EmployeesScreen() ;


  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  List<dynamic> employeeHR = [];
  List<dynamic> employeeIT = [];
  downloadData(){
    employeeHR.clear();
    employeeIT.clear();

    employeeHR.add({"firstName":"Name 1","lastName":"last Name","id":1});
    employeeHR.add({"firstName":"Name 2","lastName":"last Name 2","id":2});
    employeeHR.add({"firstName":"Name 3","lastName":"last Name 3","id":3});
    employeeHR.add({"firstName":"Name 4","lastName":"last Name 4","id":4});



    Future.delayed(Duration(seconds: 1)).then((value) =>  EmployeeHRStream.getInstance().reload(true));


    employeeIT.add({"firstName":"Name 5","lastName":"last Name 5","id":5});
    employeeIT.add({"firstName":"Name 6","lastName":"last Name 6","id":6});
    employeeIT.add({"firstName":"Name 7","lastName":"last Name 7","id":7});
    employeeIT.add({"firstName":"Name 8","lastName":"last Name 8","id":8});
    Future.delayed(Duration(seconds: 1)).then((value) =>  EmployeeITStream.getInstance().reload(true));

    EmployeeDeleteStream.getInstance().listen.listen((event) {
      if(event!=null){
        if(event["employeetype"] == EmloyeType.IT){
          if(employeeIT.length>0){
            for(int i = 0 ; i < employeeIT.length ; i++){
              if(event["employeetype"] ==employeeIT[i]["id"] ){
                employeeIT.removeAt(i);
                EmployeeITStream.getInstance().reload(true);
                break;

              }
            }
          }
        }else   if(event["employeetype"] == EmloyeType.HR){
          if(employeeHR.length>0){
            for(int i = 0 ; i < employeeHR.length ; i++){
              if(event["employeetype"] ==employeeHR[i]["id"] ){
                employeeHR.removeAt(i);
                EmployeeHRStream.getInstance().reload(true);
                break;

              }
            }
          }
        }else{
          //unknown
        }
      }
    });

  }

  Stream<bool>  prepareHRStream(){
    Future.delayed(Duration(seconds: 2)).then((value) {
      EmployeeHRStream.getInstance().reload(true);
    });
    return EmployeeHRStream.getInstance().listen;
  }
  Stream<bool>   prepareITStream(){
    Future.delayed(Duration(seconds: 2)).then((value) {
      EmployeeITStream.getInstance().reload(true);
    });
    return EmployeeITStream.getInstance().listen;
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    downloadData();

  }

  @override
  Widget build(BuildContext context) {
    // Future.delayed(Duration(seconds: 2)).then((value) {
    //   EmployeeHRStream.getInstance().reload(true);
    //   EmployeeITStream.getInstance().reload(true);
    // });



    return  DefaultTabController(
      length: 2,
      child: Scaffold(floatingActionButton: FloatingActionButton.extended(onPressed: (){  downloadData();}, label: Text("Refresh")),
        appBar: AppBar(

          bottom: const TabBar(
            tabs: [
              Tab(text: "IT",),
              Tab(text: "HR",),

            ],
          ),
          title: const Text('Employee List'),
        ),
        body:  TabBarView(
          children: [
          StreamBuilder<bool>(

          stream:prepareITStream(),
           builder: (c, snapsot) {
           //  EmployeeITStream.getInstance().reload(true);
            if(snapsot.hasData){
              return employeeIT.length>0? ListView.builder(shrinkWrap: true,
                itemCount: employeeIT.length,
                itemBuilder: (context, index) {
                  return ListTile(trailing: IconButton(onPressed: (){
                    employeeIT.removeAt(index);
                    EmployeeITStream.getInstance().reload(true);
                  //  EmployeeDeleteStream.getInstance().reload({"id": employeeIT[index]["id"],"employeetype": EmloyeType.IT});

                  },icon: Icon(Icons.delete),),
                    title: Text( employeeIT[index]["firstName"]),
                  );
                },
              ):Center(child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text("No Data"),
              ),);
            }else{
              Future.delayed(Duration(seconds: 1)).then((value) =>  EmployeeITStream.getInstance().reload(true) );

             // EmployeeITStream.getInstance().reload(true);
              return Scaffold(body: Center(child: CircularProgressIndicator(),),);
            }
           }),
            StreamBuilder<bool>(

                stream:prepareHRStream(),
                builder: (c, snapsot) {
                 // EmployeeHRStream.getInstance().reload(true);
                  if(snapsot.hasData){
                    return employeeHR.length>0? ListView.builder(shrinkWrap: true,
                      itemCount: employeeHR.length,
                      itemBuilder: (context, index) {
                        return ListTile(trailing: IconButton(onPressed: (){
                          employeeHR.removeAt(index);
                          EmployeeHRStream.getInstance().reload(true);
                        //  EmployeeDeleteStream.getInstance().reload({"id": employeeIT[index]["id"],"employeetype": EmloyeType.HR});

                        },icon: Icon(Icons.delete),),
                          title: Text( employeeHR[index]["firstName"]),
                        );
                      },
                    ):Center(child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text("No Data"),
                  ),);
                  }else{
                    Future.delayed(Duration(seconds: 1)).then((value) =>  EmployeeHRStream.getInstance().reload(true) );

                    return Scaffold(body: Center(child: CircularProgressIndicator(),),);
                  }
                }),

          ],
        ),
      ),
    );

  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          // Column is also a layout widget. It takes a list of children and
          // arranges them vertically. By default, it sizes itself to fit its
          // children horizontally, and tries to be as tall as its parent.
          //
          // Invoke "debug painting" (press "p" in the console, choose the
          // "Toggle Debug Paint" action from the Flutter Inspector in Android
          // Studio, or the "Toggle Debug Paint" command in Visual Studio Code)
          // to see the wireframe for each widget.
          //
          // Column has various properties to control how it sizes itself and
          // how it positions its children. Here we use mainAxisAlignment to
          // center the children vertically; the main axis here is the vertical
          // axis because Columns are vertical (the cross axis would be
          // horizontal).
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
